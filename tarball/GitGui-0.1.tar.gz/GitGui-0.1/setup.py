#!/usr/bin/python2.7

"""GitGui Project"""

__version__ =  '1.1.1'

from setuptools import find_packages, setup

setup(name = 'GitGui',
	package = ['GitGui'],
	version = '0.1',
	descripiton = 'A test module:GitGui',
	Summary = 'A test module:GitGui',
	long_description = 'A module for pushing a file to your github repo',
	platforms = ["Linux"],
	author = "Rahul Mishra",
	author_email = "priyrahulmishra@gmail.com",
	url= "https://github.com/Rahul91/GitGui",
	download_url = "https://github.com/Rahul91/GitGui/tarball/0.1",
	license = "MIT",
	py_modules = ['github', 'bs4', 'Tkinter', 'urllib2'],
	keywords = ['Git', 'Github', 'Python', 'GUI'],
	packages = find_packages()
	)